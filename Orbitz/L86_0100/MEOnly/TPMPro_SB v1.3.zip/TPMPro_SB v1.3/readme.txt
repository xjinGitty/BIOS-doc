How to provision TPM:
-- Make sure to run the TpmPro13.bat script file as Administrator
-- Ensure all files are in same directory
-- Supported on WinPE or WIN7 admin command prompt
-- Run in following order:
	1. txt_wtpm.exe -f aux2_def.xml
	2. txt_wtpm.exe -f ps_def.xml
	3. txt_wtpm.exe -f ps_any.xml


Files included in Package:	
aux2_cap.xml             -- Reads AUX2 Capability 
aux2_def.xml             -- Defines AUX2 Index 
aux2_read.xml            -- Reads AUX2 Index
aux50000002_remove.xml   -- Removes deprecated AUX index (0x50000002) if TPM not locked
nv_lock.xml              -- Locks NV Indicies 
production_ps_any.xml    -- Defines PS Index for productions system
ps_any.xml               -- Set PS Index for any
ps_cap.xml               -- Reads PS Capability
ps_def.xml               -- Defines PS index
ps_read.xml              -- Reads PS INdex
ps_wp.xml                -- Write protects PS Index 
ReleaseNotes.pdf         -- Build information
tnttpm64.sys             -- Driver (64-bit)
txt_wtpm.exe             -- Application Binary (64-bit)
tnttpm32.sys             -- Driver (32-bit)
txt_wtpm32.exe           -- Application Binary (32-bit)
usage.txt                -- Command line syntax


